<?php
/**
 * Plugin Name: PyShell
 * Version: 2.4.6
 * Author: @JoelGMSec & @3v4Si0N
 * Author URI: /wp-content/plugins/wordpress/shell.php
 * License: GPL3
 */
?>
